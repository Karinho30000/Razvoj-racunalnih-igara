using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class Paddle : MonoBehaviour
{
    [SerializeField] float minX = 1f;
    [SerializeField] float maxX = 15f;
    [SerializeField] Ball ball;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log(Input.mousePosition.x/Screen.width*16);
        float mousePos = Input.mousePosition.x / Screen.width * 16;
        Vector2 paddlePos = new Vector2(transform.position.x, transform.position.y);
        paddlePos.x = Mathf.Clamp(mousePos, minX, maxX);

        transform.position = paddlePos;
    }



    private void OnTriggerEnter2D(Collider2D other)
    {
        StartCoroutine(ball.SlowDownBallCoroutine());
        Destroy(other.gameObject);
    }
}
