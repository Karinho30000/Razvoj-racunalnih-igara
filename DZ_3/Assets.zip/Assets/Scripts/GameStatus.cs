using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameStatus : MonoBehaviour
{


    [SerializeField] int pointsPerBlockDestroyed = 15;
    [SerializeField] int currentScore = 0;
    [SerializeField] TextMeshProUGUI scoreText;

    public void Awake()
    {
        string activeSceneName = SceneManager.GetActiveScene().name;
        int gameStatusCount = FindObjectsOfType<GameStatus>().Length;

        // Check if the active scene is "Game Over" or "Win"
        if (activeSceneName == "Game Over" || activeSceneName == "Win" || gameStatusCount > 1)
        {
            // If it's "Game Over" or "Win", destroy this GameObject
            Destroy(gameObject);
        }
        else
        {
            // Otherwise, ensure this GameObject persists across scene changes
            DontDestroyOnLoad(gameObject);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        scoreText.text = currentScore.ToString();

    }
    public void AddToScore() {
        currentScore += pointsPerBlockDestroyed;
        scoreText.text = currentScore.ToString();
    }

    public void ResetGame() {
        currentScore = 0;
        SceneManager.LoadScene("Level1");
    } 



    // Update is called once per frame
    void Update()
    {
        
    }
}
