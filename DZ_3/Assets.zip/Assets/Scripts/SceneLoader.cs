using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{

    public void LoadNextScene()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex + 1);
    }

    public void LoadStartScene()
    {
        ResetGameStatus();
        SceneManager.LoadScene(1);
    }

    public void QuitRequest()
    {
        Application.Quit();
    }

    private void ResetGameStatus()
    {
        // Find the GameStatus object
        GameStatus gameStatus = FindObjectOfType<GameStatus>();

        // If found, reset the game status
        if (gameStatus != null)
        {
            gameStatus.ResetGame();
        }
    }
}
