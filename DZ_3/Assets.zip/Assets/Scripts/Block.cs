using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    [SerializeField] AudioClip breakSound;
    public float fallSpeed;
    Level level;
    [SerializeField] GameObject sparklesVFX;
    [SerializeField] Sprite[] hitSprites;
    [SerializeField] int maxHits;
    [SerializeField] int timesHit;
    public Transform powerUp;


    private void Start()
    {
        level = FindObjectOfType<Level>();
        level.CountBreakableBlocks();        
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        timesHit++;
        if (timesHit >= maxHits) {

            int randChance = Random.Range(1, 101);
            if (randChance < 35)
            {
                Instantiate(powerUp, transform.position, transform.rotation);
            }

            AudioSource.PlayClipAtPoint(breakSound, Camera.main.transform.position);
            level.BlockDestroyed();
            FindObjectOfType<GameStatus>().AddToScore();
            Destroy(gameObject);
            GameObject sparkles = Instantiate(sparklesVFX, transform.position, transform.rotation);
            Destroy(sparkles, 1f);
        }
        else
        {
            int spriteIndex = timesHit - 1;
            GetComponent<SpriteRenderer>().sprite = hitSprites[spriteIndex];
        }

        
        
    }
}
