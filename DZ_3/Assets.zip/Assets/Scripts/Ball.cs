using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{

    [SerializeField] Paddle paddle;
    [SerializeField] AudioClip[] ballSounds;

    public float ballSpeed = 12.5f;
    Vector2 paddleToBallVector;
    bool hasStarted = false;

    AudioSource myAudioSource;

    // Start is called before the first frame update
    void Start()
    {
        paddleToBallVector = transform.position - paddle.transform.position;
        myAudioSource = GetComponent<AudioSource>();
        
    }

    // Update is called once per frame
    void Update()
    {
        LockAndShootBall();

    }

    private void LockAndShootBall()
    {
        if (!hasStarted)
        {
            Vector2 paddlePos = new Vector2(paddle.transform.position.x, paddle.transform.position.y);
            transform.position = paddlePos + paddleToBallVector;
        }


        if (Input.GetMouseButtonDown(0))
        {
            hasStarted = true;

            Shoot();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        AudioClip clip = ballSounds[UnityEngine.Random.Range(0, ballSounds.Length)];
        myAudioSource.PlayOneShot(clip);
    }

    public void Shoot()
    {
        // Set the ball's velocity to shoot it
        GetComponent<Rigidbody2D>().velocity = new Vector2(2f, ballSpeed);
    }

    public IEnumerator SlowDownBallCoroutine()
    {
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        rb.velocity /= 1.25f;

        yield return new WaitForSeconds(10f);

        // Restore the original velocity after the duration
        rb.velocity *= 1.25f;
    }

}
