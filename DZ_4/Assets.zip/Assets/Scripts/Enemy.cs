using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] float health = 300f;
    [SerializeField] GameObject projectile;
    [SerializeField] float projectileSpeed = 10f;
    [SerializeField] float minTime = 0.2f;
    [SerializeField] float maxTime = 3f;
    [SerializeField] float shotCounter;
    // Start is called before the first frame update
    void Start()
    {
        shotCounter = Random.Range(minTime, maxTime);
    }

    // Update is called once per frame
    void Update()
    {
        CountAndShoot();
    }

    private void CountAndShoot()
    {
        shotCounter -= Time.deltaTime;
        if (shotCounter <= 0f)
        {
            Fire();
            shotCounter = Random.Range(minTime, maxTime);
        }
    }

    private void Fire()
    {
        GameObject laser = Instantiate(projectile, transform.position, Quaternion.identity) as GameObject;
        laser.GetComponent<Rigidbody2D>().velocity = new Vector2(0f, -projectileSpeed);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        DamageDealer damageDealer = collision.gameObject.GetComponent<DamageDealer>();
        if (damageDealer != null)
        {
            // Damage calculation
            health -= damageDealer.GetDamage();
            damageDealer.Hit();
            // Update the total damage taken by this enemy
            EnemyManager.AddDamage(damageDealer.GetDamage());
            FindObjectOfType<ScoreManager>().AddScore(damageDealer.GetDamage());
        }

        if (health <= 0)
        {
            Destroy(gameObject);
            EnemyManager.RegisterEnemyDestruction();
        }

    }

}
