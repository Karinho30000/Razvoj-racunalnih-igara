using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyManager : MonoBehaviour
{
    // Static variable to track the total damage taken by all enemy instances
    static int totalDamageTaken = 0;
    static int destroyedEnemies = 0;

    // Method to add damage to the total damage taken
    public static void AddDamage(int damage)
    {
        totalDamageTaken += damage;
    }

    // Method to get the total damage taken by all enemies
    public static int GetTotalDamageTaken()
    {
        return totalDamageTaken;
    }

    // Method to reset the total damage taken and enemy count
    public static void ResetTotalDamageTaken()
    {
        totalDamageTaken = 0;
    }

    public static void ResetEnemiesDestroyed()
    {
        destroyedEnemies = 0;
    }

    // Method to register an enemy destruction
    public static void RegisterEnemyDestruction()
    {
        destroyedEnemies++;

        // Check if all enemies are destroyed
        if (destroyedEnemies >= 31)
        {
            // Transition to win scene
            SceneManager.LoadScene("Win");
        }
    }
}
