using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPath : MonoBehaviour
{
    [SerializeField] List<Transform> waypoints;
    [SerializeField] WaveConfig waveConfig;

    int waypointIndex = 0;
    bool isVisible = false;

    void Start()
    {
        waypoints = waveConfig.GetWayPoints();
        transform.position = waypoints[waypointIndex].transform.position;
    }

    public void SetWaveConfig(WaveConfig waveConfig)
    {
        this.waveConfig = waveConfig;
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        CheckVisibility();
    }

    private void Move()
    {
        if (waypointIndex <= waypoints.Count - 1)
        {
            var targetPos = waypoints[waypointIndex].transform.position;
            transform.position = Vector2.MoveTowards(transform.position, targetPos, waveConfig.GetMoveSpeed() * Time.deltaTime);

            if (transform.position == targetPos)
            {
                waypointIndex++;
            }
        }
        else
        {
            //Destroy(gameObject);
            waypointIndex = 0;
        }
    }

    private void CheckVisibility()
    {
        if (!isVisible && IsOnCanvas())
        {
            isVisible = true;
            gameObject.SetActive(true); // Make the enemy visible
        }
    }

    private bool IsOnCanvas()
    {
        Vector3 screenPoint = Camera.main.WorldToViewportPoint(transform.position);
        return screenPoint.x >= 0 && screenPoint.x <= 1 && screenPoint.y >= 0 && screenPoint.y <= 1;
    }
}
