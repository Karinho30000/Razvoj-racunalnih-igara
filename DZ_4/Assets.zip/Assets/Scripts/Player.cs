using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    [SerializeField] float moveSpeed = 10f;
    [SerializeField] float padding = 0.6f;
    [SerializeField] GameObject laserPrefab;
    [SerializeField] GameObject powerUpLaserPrefab;
    Coroutine firingCoroutine;
    [SerializeField] float RPF = 0.2f;
    [SerializeField] float health = 200f;
    [SerializeField] Image healthBar;


    bool isPowerUpActive = false;

    float Xmin, Xmax, Ymin, Ymax;

    Color originalColor;

    void Start()
    {
        SetupMoveBoundaries();
        originalColor = GetComponent<SpriteRenderer>().color;
    }

    private void SetupMoveBoundaries()
    {
        Camera mainCamera = Camera.main;
        float aspectRatio = 9f / 16f; // Desired aspect ratio (9:16)
        float cameraSize = mainCamera.orthographicSize;
        float screenWidth = cameraSize * aspectRatio * 2f;
        float screenHeight = cameraSize * 2f;

        // Calculate min and max positions based on camera size and aspect ratio
        Xmin = mainCamera.transform.position.x - screenWidth / 2f + padding;
        Xmax = mainCamera.transform.position.x + screenWidth / 2f - padding;
        Ymin = mainCamera.transform.position.y - screenHeight / 2f + padding;
        Ymax = mainCamera.transform.position.y + screenHeight / 2f - padding;
    }


    void Update()
    {
        Move();
        Fire();
        CheckPowerUp();
    }

    private void Fire()
    {
        if (Input.GetButtonDown("Fire1")){
            firingCoroutine = StartCoroutine(FireCont());
        }

        if (Input.GetButtonUp("Fire1"))
        {
            StopCoroutine(firingCoroutine);
        }

    }

    IEnumerator FireCont()
    {
        while (true)
        {
            GameObject laserPrefabToUse = isPowerUpActive ? powerUpLaserPrefab : laserPrefab;
            GameObject laser = Instantiate(laserPrefabToUse, transform.position, Quaternion.identity) as GameObject;
            if (isPowerUpActive)
            {

                laser.GetComponent<DamageDealer>().SetDamage(laser.GetComponent<DamageDealer>().GetDamage() * 3);
                RPF = 0.25f;
            }
            laser.GetComponent<Rigidbody2D>().velocity = new Vector2(0f, 10f);
            yield return new WaitForSeconds(RPF);
        }
    }

    private void Move()
    {
        var deltaX = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;
        var deltaY = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;

        var newXPos = Math.Clamp(transform.position.x + deltaX, Xmin, Xmax);
        var newYPos = Math.Clamp(transform.position.y + deltaY, Ymin, Ymax);

        transform.position = new Vector2(newXPos, newYPos);
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        DamageDealer damageDealer = collision.gameObject.GetComponent<DamageDealer>();
        health -= damageDealer.GetDamage();
        healthBar.fillAmount = health / 250f;
        damageDealer.Hit();
        if (health <= 0)
        {
            Destroy(gameObject);
            SceneLoader.LoadNextScene();
        }
    }


    void CheckPowerUp()
    {
        int totalDamageDealt = EnemyManager.GetTotalDamageTaken();
        if (!isPowerUpActive && totalDamageDealt >= 1000)
        {
            isPowerUpActive = true;
            SpriteRenderer shipRenderer = GetComponent<SpriteRenderer>();
            shipRenderer.color = new Color(1f, 0.5f, 0f);
            StartCoroutine(DeactivatePowerUp());
        }
    }

    IEnumerator DeactivatePowerUp()
    {
        yield return new WaitForSeconds(5f); // Wait for 5 seconds
        isPowerUpActive = false; // Deactivate power-up
        GetComponent<SpriteRenderer>().color = originalColor; // Reset ship color
        EnemyManager.ResetTotalDamageTaken(); // Reset total damage counter
        RPF = 0.2f;
    }

}
