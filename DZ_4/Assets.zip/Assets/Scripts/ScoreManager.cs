using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    [SerializeField] int score = 0;
    [SerializeField] TextMeshProUGUI scoreText;

    void Start()
    {
        UpdateScoreText();
    }

    // Method to add points to the score
    public void AddScore(int points)
    {
        score += points;
        scoreText.text = score.ToString();
        // You can add any additional logic here, such as updating UI elements or triggering events
    }

    // Method to update the score text
    void UpdateScoreText()
    {
        scoreText.text = score.ToString(); // Update the score text

    }
}
