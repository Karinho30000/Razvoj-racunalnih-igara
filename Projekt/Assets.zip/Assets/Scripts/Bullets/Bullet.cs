using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    private Rigidbody2D myBody;
    [SerializeField] private float moveSpeed = 2.5f;
    [SerializeField] public float damageAmount = 25f;
    [SerializeField] private float deactivateTimer = 3f;
    [SerializeField] private bool destroyObj;

    private void Awake()
    {
        myBody = GetComponent<Rigidbody2D>();

        Invoke("DeactivateBullet", deactivateTimer);
    }

    public void MoveInDirection(Vector3 direction)
    {
        myBody.velocity = direction*moveSpeed;
    }

    public void DeactivateBullet()
    {
        if(destroyObj)
            Destroy(gameObject);
        else
            gameObject.SetActive(false); 
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision is BoxCollider2D && collision.CompareTag(TagManager.ENEMY_TAG))
        {
            

            // Assuming the enemy has a method called TakeDamage to handle the damage
            Enemy enemy = collision.GetComponentInParent<Enemy>(); // Replace 'Enemy' with your actual script name
            if (enemy != null)
            {
                enemy.TakeDamage(damageAmount);
            }

            DeactivateBullet();
        }

        if (collision is BoxCollider2D && collision.CompareTag(TagManager.BOSS_TAG))
        {
            

            // Assuming the enemy has a method called TakeDamage to handle the damage
            BossEnemy bossEnemy = collision.GetComponentInParent<BossEnemy>(); // Replace 'Enemy' with your actual script name
            if (bossEnemy != null)
            {
                bossEnemy.TakeDamage(damageAmount);
            }

            DeactivateBullet();
        }

        if (collision.CompareTag((TagManager.BLOCKING_TAG)))
        {
            DeactivateBullet();
        }
    }
}
