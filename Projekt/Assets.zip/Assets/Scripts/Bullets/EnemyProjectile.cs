using UnityEngine;

public class EnemyProjectile : MonoBehaviour
{
    [SerializeField] private float speed = 5f;
    [SerializeField] private float damageAmount = 10f;
    private Vector2 moveDirection;

    private void Start()
    {
        Destroy(gameObject, 5f); // Destroy the projectile after 5 seconds to prevent memory leaks
    }

    public void SetDirection(Vector2 direction)
    {
        moveDirection = direction.normalized;
    }

    private void Update()
    {
        transform.Translate(moveDirection * speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            PlayerHealth playerHealth = collision.GetComponent<PlayerHealth>();

            if (playerHealth != null)
            {
                // Apply damage through the PlayerHealth script
                playerHealth.TakeDamage(damageAmount, moveDirection);

                // Destroy the projectile after it hits the player
                Destroy(gameObject);
            }
        }

        // Destroy the projectile if it hits something else, like a wall
        if (collision.CompareTag("Blocking"))
        {
            Destroy(gameObject);
        }
    }
}
