using System.Collections;
using UnityEngine;

public class MainMenuManager : MonoBehaviour
{
    [SerializeField] private GameObject mainMenuPanel; // The panel GameObject
    [SerializeField] private Camera mainCamera; // The main camera in the scene
    [SerializeField] private float zoomOutSize = 7f; // The size of the camera when zoomed out
    [SerializeField] private float zoomInSize = 5f; // The size of the camera when zoomed in (default)
    [SerializeField] private float zoomDuration = 1f; // The duration of the zoom transition

    [SerializeField] private AudioSource menuMusic;

    private bool isGameStarted = false;

    private void Start()
    {
        // Show the main menu panel and zoom out the camera at the start
        if (mainMenuPanel != null)
        {
            mainMenuPanel.SetActive(true);
        }
        if (mainCamera != null)
        {
            mainCamera.orthographicSize = zoomOutSize;
        }

        if (MusicManager.instance != null)
        {
            MusicManager.instance.ChangeMusicSource(menuMusic);
            menuMusic.Play();
        }
    }

    private void Update()
    {
        // Check if the player presses Enter and the game hasn't started yet
        if (!isGameStarted && Input.GetKeyDown(KeyCode.Return))
        {
            StartCoroutine(StartGame());
        }
    }

    private IEnumerator StartGame()
    {
        isGameStarted = true;

        // Zoom in the camera
        float elapsedTime = 0f;
        float currentZoomSize = mainCamera.orthographicSize;

        while (elapsedTime < zoomDuration)
        {
            mainCamera.orthographicSize = Mathf.Lerp(currentZoomSize, zoomInSize, elapsedTime / zoomDuration);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        mainCamera.orthographicSize = zoomInSize;

        // Hide the main menu panel after the zoom is complete
        if (mainMenuPanel != null)
        {
            mainMenuPanel.SetActive(false);
        }
    }
}
