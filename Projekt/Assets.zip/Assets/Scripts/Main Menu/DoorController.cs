using UnityEngine;

public class DoorController : MonoBehaviour
{
    [SerializeField] private Animator doorAnimator;
    [SerializeField] private float delayBeforeDisablingCollider = 1.0f; // Delay to allow animation to start
    private AudioSource gateOpenSound;
    private Collider2D doorCollider;
    private bool hasOpened = false; // Flag to check if the door has already been opened

    private void Awake()
    {
        // Assign components
        gateOpenSound = GetComponent<AudioSource>();
        doorCollider = GetComponent<Collider2D>();

        // Ensure components are found
        if (doorCollider == null)
        {
            Debug.LogError("Collider2D component is missing on the Door GameObject.");
        }

        if (doorAnimator == null)
        {
            Debug.LogError("Animator component is missing or not assigned on the Door GameObject.");
        }

        if (gateOpenSound == null)
        {
            Debug.LogError("AudioSource component is missing on the Door GameObject.");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag(TagManager.PLAYER_TAG) && !hasOpened)
        {
            // Mark the door as opened to prevent further interaction
            hasOpened = true;

            // Play the sound
            gateOpenSound.Play();

            // Trigger the door opening animation
            doorAnimator.SetTrigger("Open"); // Use a trigger parameter instead of directly playing an animation

            // Disable the collider after a delay
            Invoke(nameof(RemoveCollider), delayBeforeDisablingCollider);
        }
    }

    private void RemoveCollider()
    {
        // Disable the collider to prevent further interaction
        if (doorCollider != null)
        {
            doorCollider.enabled = false;
        }
    }
}
