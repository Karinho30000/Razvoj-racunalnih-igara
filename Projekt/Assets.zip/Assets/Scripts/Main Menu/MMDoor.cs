using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MMDoor : MonoBehaviour
{
    [SerializeField] private string levelName;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag(TagManager.PLAYER_TAG))
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(levelName);
        }
    }
}
