using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class MusicManager : MonoBehaviour
{
    public static MusicManager instance;

    [SerializeField] private AudioSource backgroundMusic;
    [SerializeField] private Button musicToggleButton;
    [SerializeField] private Sprite musicOnSprite;
    [SerializeField] private Sprite musicOffSprite;
    private bool isMusicMuted = false;
    private bool canToggle = true;

    private void Awake()
    {
        // Ensure only one instance of MusicManager exists per scene
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        // Initialize button sprite and add listener
        UpdateButtonSprite();
        if (musicToggleButton != null)
        {
            musicToggleButton.onClick.AddListener(ToggleMusic);
            Debug.Log("Listener added");
        }
    }

    private void Start()
    {
        Debug.Log("MusicManager Start method called");
        if (backgroundMusic != null)
        {
            backgroundMusic.mute = isMusicMuted;
            if (!isMusicMuted)
            {
                backgroundMusic.Play();
                Debug.Log("Music started playing");
            }
        }
    }

    public void ToggleMusic()
    {
        Debug.Log("ToggleMusic method called");
        if (!canToggle) return;

        isMusicMuted = !isMusicMuted;
        if (backgroundMusic != null)
        {
            backgroundMusic.mute = isMusicMuted;
            Debug.Log("Music muted state: " + isMusicMuted);
        }

        UpdateButtonSprite();
        StartCoroutine(ToggleCooldown());
    }


    private IEnumerator ToggleCooldown()
    {
        canToggle = false;
        yield return new WaitForSeconds(0.2f);
        canToggle = true;
    }

    private void UpdateButtonSprite()
    {
        if (musicToggleButton != null)
        {
            musicToggleButton.image.sprite = isMusicMuted ? musicOffSprite : musicOnSprite;
            Debug.Log("Button sprite updated to: " + (isMusicMuted ? "Off" : "On"));
        }
    }

    public void ChangeMusicSource(AudioSource newMusicSource)
    {
        if (backgroundMusic != null)
        {
            backgroundMusic.Stop(); // Stop the current music
        }
        backgroundMusic = newMusicSource;
        if (!isMusicMuted)
        {
            backgroundMusic.Play(); // Play the new music if not muted
        }
    }

    public bool IsMusicMuted()
    {
        return isMusicMuted;
    }
}
