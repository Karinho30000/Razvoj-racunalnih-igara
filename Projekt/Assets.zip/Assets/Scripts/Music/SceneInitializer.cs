using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneInitializer : MonoBehaviour
{
    [SerializeField] private AudioSource gameMusic;

    private void Start()
    {
        // Ensure MusicManager instance exists
        if (MusicManager.instance != null)
        {
            MusicManager.instance.ChangeMusicSource(gameMusic);
            gameMusic.Play();
        }
    }
}
