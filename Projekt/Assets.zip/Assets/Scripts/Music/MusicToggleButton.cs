using UnityEngine;
using UnityEngine.UI;

public class MusicToggleButton : MonoBehaviour
{
    [SerializeField] private Sprite musicOnSprite; // Sprite when music is on
    [SerializeField] private Sprite musicOffSprite; // Sprite when music is off

    private Button toggleButton;
    private Image buttonImage;

    private void Awake()
    {
        toggleButton = GetComponent<Button>();
        buttonImage = GetComponent<Image>();

        if (toggleButton != null)
        {
            toggleButton.onClick.AddListener(ToggleMusic);
            Debug.Log("Button listener added.");
        }
        else
        {
            Debug.LogError("Button component not found!");
        }
    }

    private void Start()
    {
        UpdateButtonSprite();
    }

    private void ToggleMusic()
    {
        if (MusicManager.instance != null)
        {
            MusicManager.instance.ToggleMusic();
            UpdateButtonSprite();
            Debug.Log("Music toggled.");
        }
        else
        {
            Debug.LogError("MusicManager instance not found!");
        }
    }

    private void UpdateButtonSprite()
    {
        if (MusicManager.instance != null)
        {
            buttonImage.sprite = MusicManager.instance.IsMusicMuted() ? musicOffSprite : musicOnSprite;
            Debug.Log("Button sprite updated.");
        }
    }
}
