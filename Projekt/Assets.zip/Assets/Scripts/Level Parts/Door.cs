using UnityEngine;

public class Door : MonoBehaviour
{
    [SerializeField] private int requiredKills = 3; // Number of enemies that need to be destroyed
    private int currentKills = 0;

    private BoxCollider2D boxCollider;
    private SpriteRenderer[] spriteRenderers;

    private void Awake()
    {
        boxCollider = GetComponent<BoxCollider2D>();
        spriteRenderers = GetComponentsInChildren<SpriteRenderer>(); // Get all SpriteRenderers in children
    }

    public void RegisterKill()
    {
        currentKills++;

        if (currentKills >= requiredKills)
        {
            OpenDoor();
        }
    }

    private void OpenDoor()
    {
        // Hide the door by disabling all child SpriteRenderers
        foreach (var renderer in spriteRenderers)
        {
            renderer.enabled = false;
        }

        boxCollider.enabled = false; // Disable the collider so the player can pass through
    }
}
