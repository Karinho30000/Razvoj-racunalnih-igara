using UnityEngine;

public class ExitDoor : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    private BoxCollider2D boxCollider;
    public GameManager Manager;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        boxCollider = GetComponent<BoxCollider2D>();

        // Initially, hide the door
        spriteRenderer.enabled = false;
        boxCollider.enabled = false;
    }

    public void ShowDoor()
    {
        // Show the door by enabling the SpriteRenderer and the BoxCollider
        spriteRenderer.enabled = true;
        boxCollider.enabled = true;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag(TagManager.PLAYER_TAG)){
            Manager.Win();
        }
    }
}

