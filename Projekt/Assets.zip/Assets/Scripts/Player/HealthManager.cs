using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthManager : MonoBehaviour
{
    public Image healthBar;
    private PlayerHealth health;

    private void Awake()
    {
        // Find the PlayerHealth component in the scene
        health = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
    }

    private void Update()
    {
        // Update the health bar fill amount based on the player's health
        healthBar.fillAmount = health.GetHealthPercentage();
    }

}
