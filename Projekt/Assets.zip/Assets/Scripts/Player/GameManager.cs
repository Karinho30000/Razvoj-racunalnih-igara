using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject gameOverUI;
    public GameObject WinUI;
    [SerializeField] private AudioSource newMusic;
    [SerializeField] private AudioSource battleMusic;
    [SerializeField] private AudioSource deathMusic;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void gameOver()
    {
        MusicManager.instance.ChangeMusicSource(deathMusic);
        gameOverUI.SetActive(true);
        if (battleMusic != null)
        {
            battleMusic.Stop();
        }
        if (deathMusic != null)
        {
            deathMusic.Play();
        }
    }

    public void Win()
    {
        MusicManager.instance.ChangeMusicSource(newMusic);
        WinUI.SetActive(true);
        if (battleMusic != null)
        {
            battleMusic.Stop();
        }
        if (newMusic != null)
        {
            newMusic.Play();
        }
    }

    public void Restart()
    {
        SceneManager.LoadScene("Main Menu");
    }

    public void Quit()
    {
        Application.Quit();
    }
}
