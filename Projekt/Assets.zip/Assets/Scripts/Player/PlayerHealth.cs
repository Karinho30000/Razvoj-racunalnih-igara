using System.Collections;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public float maxHealth = 100f;
    public float knockbackForce = 5f; // The initial force of the knockback
    public float knockbackDuration = 0.2f; // Duration of the knockback effect
    private float currentHealth;
    private Rigidbody2D rb;

    private bool isDead;
    public GameManager manager;

    private void Start()
    {
        currentHealth = maxHealth;
        rb = GetComponent<Rigidbody2D>();
    }

    public void TakeDamage(float amount, Vector2 knockbackDirection)
    {
        currentHealth -= amount;
        Debug.Log("Player Health: " + currentHealth);

        // Apply knockback with a timed duration
        StartCoroutine(ApplyKnockback(knockbackDirection));

        if (currentHealth <= 0f && !isDead)
        {
            isDead = true;
            gameObject.SetActive(false);
            manager.gameOver();
        }
    }

    private IEnumerator ApplyKnockback(Vector2 direction)
    {
        // Normalize the direction and apply the knockback force
        rb.AddForce(direction.normalized * knockbackForce, ForceMode2D.Impulse);

        // Disable player control or reduce the velocity over time
        float elapsedTime = 0f;

        while (elapsedTime < knockbackDuration)
        {
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // Stop the knockback by setting the velocity to zero
        rb.velocity = Vector2.zero;
    }

    public float GetHealthPercentage()
    {
        return currentHealth / maxHealth; // Returns a value between 0 and 1
    }

}
