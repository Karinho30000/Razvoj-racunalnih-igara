using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShootingManager : MonoBehaviour
{
    [SerializeField] private float shootingTimerLimit = 0.2f;
    private float shootingTimer;
    [SerializeField] private Transform bulletSpawnPos;
    private PlayerWeaponManager weaponManager;

    private void Awake()
    {
        weaponManager = GetComponent<PlayerWeaponManager>();
    }

    private void Update()
    {
        HandleShooting();
    }

    void HandleShooting()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (Time.time > shootingTimer)
            {
                shootingTimer = Time.time + shootingTimerLimit;
                CreateBullet();
            }
        }
    }

    void CreateBullet()
    {
        weaponManager.Shoot(bulletSpawnPos.position);
    }
}
