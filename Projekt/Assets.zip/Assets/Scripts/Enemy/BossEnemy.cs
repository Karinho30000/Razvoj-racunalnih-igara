using System.Collections;
using UnityEngine;

public class BossEnemy : MonoBehaviour
{
    [SerializeField] private float health = 500f; // Boss health
    private Animator animator;
    private bool isDead = false;
    [SerializeField] private ExitDoor exitDoor; // Reference to the exit door

    // Shooting properties
    [SerializeField] private GameObject projectilePrefab;  // The projectile prefab for the boss
    [SerializeField] private float projectileSpeed = 7f;   // Speed of the boss projectile
    [SerializeField] private float shootInterval = 1.5f;   // Time between shots for the boss
    [SerializeField] private float damageAmount = 10f;

    private Transform player;  // Reference to the player's position

    private void Awake()
    {
        animator = GetComponent<Animator>();
        player = GameObject.FindGameObjectWithTag("Player").transform; // Find the player by tag
    }

    private void Start()
    {
        StartCoroutine(ShootAtPlayer()); // Start shooting at the player
    }

    // Function to apply damage to the boss
    public void TakeDamage(float damageAmount)
    {
        if (isDead) return; // Prevent further damage if already dead

        health -= damageAmount;

        // Check if health is zero or below
        if (health <= 0f)
        {
            Die();
        }
    }

    // Function to handle the death of the boss
    private void Die()
    {
        isDead = true; // Mark the boss as dead to prevent further interactions
        animator.SetTrigger("Death"); // Trigger the death animation

        // Destroy the boss after the animation has finished playing
        float deathAnimationDuration = animator.GetCurrentAnimatorStateInfo(0).length;
        Invoke("DestroyBoss", deathAnimationDuration);

        if (exitDoor != null)
        {
            exitDoor.ShowDoor(); // Make the exit door visible
        }
    }

    // Function to actually destroy the boss
    private void DestroyBoss()
    {
        Destroy(gameObject);
    }

    // Shooting coroutine that continuously fires projectiles at the player
    private IEnumerator ShootAtPlayer()
    {
        while (!isDead)
        {
            yield return new WaitForSeconds(shootInterval); // Wait for the interval time

            // Calculate the direction to the player
            Vector2 direction = (player.position - transform.position).normalized;

            // Fire the middle projectile directly at the player
            FireProjectile(direction);

            // Fire the left projectile with a slight offset
            Vector2 leftOffset = Quaternion.Euler(0, 0, 30) * direction; // 15 degrees to the left
            FireProjectile(leftOffset);

            // Fire the right projectile with a slight offset
            Vector2 rightOffset = Quaternion.Euler(0, 0, -30) * direction; // 15 degrees to the right
            FireProjectile(rightOffset);

            Vector2 backOffset = Quaternion.Euler(0, 0, 180) * direction; // 15 degrees to the left
            FireProjectile(backOffset);

            Vector2 leftBackOffset = Quaternion.Euler(0, 0, 150) * direction; // 15 degrees to the left
            FireProjectile(leftBackOffset);

            Vector2 rightBackOffset = Quaternion.Euler(0, 0, -150) * direction; // 15 degrees to the right
            FireProjectile(rightBackOffset);
        }
    }

    private void FireProjectile(Vector2 direction)
    {
        // Instantiate the projectile
        GameObject projectile = Instantiate(projectilePrefab, transform.position, Quaternion.identity);

        // Set the projectile's velocity
        projectile.GetComponent<Rigidbody2D>().velocity = direction * projectileSpeed;

        // Optionally, rotate the projectile to face the direction it's moving
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        projectile.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        BossProjectile bossProjectile = projectile.AddComponent<BossProjectile>();
        bossProjectile.Initialize(damageAmount, direction);
    }
}

public class BossProjectile : MonoBehaviour
{
    private float damageAmount;
    private Vector2 knockbackDirection;

    public void Initialize(float damage, Vector2 direction)
    {
        damageAmount = damage;
        knockbackDirection = direction;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerHealth playerHealth = collision.GetComponent<PlayerHealth>();

        if (playerHealth != null)
        {
            // Apply damage and knockback
            playerHealth.TakeDamage(damageAmount, knockbackDirection);
            Destroy(gameObject); // Destroy the projectile after hitting the player
        }
        else if (collision.CompareTag("Blocking"))
        {
            Destroy(gameObject); // Destroy the projectile if it hits a blocking object
        }
    }
}

