using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFollowAndAttack : MonoBehaviour
{
    public float followRange = 10f; // Range within which the enemy follows the player
    public float moveSpeed = 2f; // Speed at which the enemy moves
    public float attackDamage = 10f; // Damage dealt to the player
    public float attackCooldown = 1f; // Time between attacks

    private Transform player; // Reference to the player
    private PlayerHealth playerHealth; // Reference to the player's health script
    private bool canAttack = false; // Whether the enemy can attack the player
    private float lastAttackTime; // Time since last attack

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        playerHealth = player.GetComponent<PlayerHealth>();
    }

    private void Update()
    {
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if (distanceToPlayer <= followRange)
        {
            // Follow the player
            transform.position = Vector2.MoveTowards(transform.position, player.position, moveSpeed * Time.deltaTime);
        }

        if (canAttack && Time.time >= lastAttackTime + attackCooldown)
        {
            // Attack the player
            AttackPlayer();
            lastAttackTime = Time.time; // Update last attack time
        }
    }

    private void AttackPlayer()
    {
        if (playerHealth != null)
        {
            // Calculate the knockback direction (from enemy to player)
            Vector2 knockbackDirection = player.position - transform.position;

            // Deal damage and apply knockback
            playerHealth.TakeDamage(attackDamage, knockbackDirection);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            canAttack = true; // Enemy can attack when in contact with the player
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            canAttack = false; // Enemy stops attacking when it moves away from the player
        }
    }

    private void OnDrawGizmosSelected()
    {
        // Visualize the follow range in the editor
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, followRange);
    }
}
