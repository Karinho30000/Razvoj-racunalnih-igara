using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] private float health = 100f;
    private Animator animator;
    private bool isDead = false;
    [SerializeField] private Door door;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    // Function to apply damage to the enemy
    public void TakeDamage(float damageAmount)
    {
        if (isDead) return; // Prevent further damage if already dead

        health -= damageAmount;

        // Check if health is zero or below
        if (health <= 0f)
        {
            Die();
        }
    }

    // Function to handle the death of the enemy
    private void Die()
    {
        isDead = true; // Mark the enemy as dead to prevent further interactions
        animator.SetTrigger("Death"); // Trigger the death animation

        // Destroy the enemy after the animation has finished playing
        // Assuming the death animation is 2 seconds long, you can adjust the delay to match the length of your animation
        float deathAnimationDuration = animator.GetCurrentAnimatorStateInfo(0).length;
        Invoke("DestroyEnemy", deathAnimationDuration);

        if (door != null)
        {
            door.RegisterKill();
        }
    }

    // Function to actually destroy the enemy
    private void DestroyEnemy()
    {
        Destroy(gameObject);
    }


}
