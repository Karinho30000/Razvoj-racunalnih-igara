using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using StarterAssets;

public class Gun : MonoBehaviour
{
    private StarterAssetsInputs _input;
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private GameObject shellPrefab;
    [SerializeField] private GameObject bulletPoint;
    [SerializeField] private GameObject shellPoint;
    [SerializeField] private float bulletSpeed = 60;
    [SerializeField] private float shellSpeed = 60;

    // Start is called before the first frame update
    void Start()
    {
        _input = transform.parent.parent.GetComponent<StarterAssetsInputs>();
    }

    // Update is called once per frame
    void Update()
    {
        if( _input.shoot)
        {
            Shoot();
            _input.shoot = false;
        }
    }

    void Shoot()
    {
        Debug.Log("Shoot!");
        GameObject bullet = Instantiate(bulletPrefab, bulletPoint.transform.position, transform.rotation);
        bullet.GetComponent<Rigidbody>().AddForce(transform.right * bulletSpeed);
        Destroy(bullet, 1);
        GameObject shell = Instantiate(shellPrefab, shellPoint.transform.position, transform.rotation);
        shell.GetComponent<Rigidbody>().AddForce(transform.forward * shellSpeed);
        Destroy(shell, 1);
    }
}
