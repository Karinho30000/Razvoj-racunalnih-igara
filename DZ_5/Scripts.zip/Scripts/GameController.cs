using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    private int enemyKillCount = 0; // Tracks the number of enemies killed
    public int killsToWin = 3;     // Number of kills required to win
    public string winningSceneName = "WinningScene"; // Name of the winning scene

    // Call this method whenever an enemy is killed
    public void EnemyKilled()
    {
        enemyKillCount++;
        Debug.Log("Enemies killed: " + enemyKillCount);

        // Check if the player has reached the required number of kills
        if (enemyKillCount >= killsToWin)
        {
            LoadWinningScene();
        }
    }

    // Load the winning scene
    private void LoadWinningScene()
    {
        SceneManager.LoadScene(winningSceneName);
    }
}
