using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AttributesManager : MonoBehaviour
{
    public int health;
    public int attackDamage;
    public bool isPlayer;
    SceneLoader loader;
    private GameController gameController;

    void Start()
    {
        gameController = FindObjectOfType<GameController>(); // Locate the GameController in the scene
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        if (isPlayer)
        {
            // If the object is the player, restart the scene
            Debug.Log("Player has died. Restarting the scene...");
            SceneManager.LoadScene(2);
        }
        else
        {
            // If the object is an enemy, destroy the enemy object
            Debug.Log("Enemy has been killed.");
            gameController.EnemyKilled();
            Destroy(gameObject);
        }
    }
}
