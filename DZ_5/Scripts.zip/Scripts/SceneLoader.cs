using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    void Update()
    {
        // Check if the "R" key is pressed
        if (Input.GetKeyDown(KeyCode.R))
        {
            RestartGame();
        }

        // Check if the "Q" key is pressed
        if (Input.GetKeyDown(KeyCode.Q))
        {
            QuitGame();
        }
    }

    // Function to restart the current scene
    public void RestartGame()
    {
        SceneManager.LoadScene(1);
    }

    // Function to quit the game
    public void QuitGame()
    {
        // This will only work in builds, not in the editor
        Application.Quit();
    }
}
